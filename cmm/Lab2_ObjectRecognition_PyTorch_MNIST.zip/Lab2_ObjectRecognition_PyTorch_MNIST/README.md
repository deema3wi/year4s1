# Lab 2 — Object recognition (MNIST) with a CNN (PyTorch)

## Setup (Windows / Linux)
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
```

## Train
```bash
python main.py train --epochs 5 --batch-size 128 --lr 0.001
```

## Evaluate
```bash
python main.py eval --checkpoint artifacts/mnist_cnn.pt
```

## Predict (random test images)
```bash
python main.py predict --checkpoint artifacts/mnist_cnn.pt --samples 8
```

## Predict (your image)
Image should be a digit on a clear background. Any PNG/JPG works.
```bash
python main.py predict --checkpoint artifacts/mnist_cnn.pt --image path/to/digit.png
```

Artifacts are saved to `./artifacts/`.
